# -*- coding: utf-8 -*-
"""
@author: Zed
@file: __init__.py.py
@time: 2024/2/18 18:19
@describe:自定义描述
"""
from .strategy_std import StrategyStd,Kline
